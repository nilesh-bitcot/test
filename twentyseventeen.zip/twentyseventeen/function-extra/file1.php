<?php
function get_post_withMeta($step, $meta1, $meta2=null, $meta3 = null){
	if($step = 'first'){
		$args = array(
		   'meta_query' => array(
		       array(
		           'key' => 'school',
		           'value' => $meta1,
		           'compare' => '=',
		       )
		   )
		);
		$query = get_posts($args);
		return $query;
	}
    if($step = 'second_hss'){
        $args = array(
           'meta_query' => array(
            'relation' => 'AND',
               array(
                   'key' => 'school',
                   'value' => $meta1,
                   'compare' => '=',
               ),
               array(
                   'key' => 'school_stream',
                   'value' => $meta2,
                   'compare' => '=',
               )
           )
        );
        $query = get_posts($args);
        return $query;    
    }
    if($step = 'dip_iti'){
        $args = array(
           'meta_query' => array(
            'relation' => 'AND',
               array(
                   'key' => 'school',
                   'value' => $meta1,
                   'compare' => '=',
               ),
               array(
                   'key' => 'after_school',
                   'value' => $meta2,
                   'compare' => '=',
               ),
               array(
                   'key' => 'after_school_stream',
                   'value' => $meta3,
                   'compare' => '=',
               )
           )
        );
        $query = get_posts($args);
        return $query;    
    }
    if($step = 'only_hss_school'){
        $args = array(
           'meta_query' => array(
            'relation' => 'AND',
               array(
                   'key' => 'school',
                   'value' => $meta1,
                   'compare' => '=',
               ),
               array(
                   'key' => 'school_stream',
                   'value' => $meta2,
                   'compare' => '=',
               )
           )
        );
        $query = get_posts($args);
        return $query; 
    }
    if($step = 'col_main'){
        $args = array(
           'meta_query' => array(
            'relation' => 'AND',
               array(
                   'key' => 'school',
                   'value' => $meta1,
                   'compare' => '=',
               ),
               array(
                   'key' => 'school_stream',
                   'value' => $meta2,
                   'compare' => '=',
               ),
               array(
                   'key' => 'college_course',
                   'value' => $meta2,
                   'compare' => '=',
               )
           )
        );
        $query = get_posts($args);
        return $query; 
    }
    
}
add_action( 'wp_footer', function(){
	echo '<pre style="color:black;">';
	// print_r(get_post_withMeta('first', '1'));
	echo "</pre>";
});
function wporg_meta_box_ajax_handler(){
	$html = '';
    if (isset($_POST['level_one'])) {
    	if(check_next_level_edu_data('tab_school_stream', $_POST['level_one'])){
    		$streams = check_next_level_edu_data('tab_school_stream', $_POST['level_one']);
    		if($streams){
                $html .= '<input type="hidden" id="res_level_one" value="'.$_POST['level_one'].'">';
	    		$html .= '<p>Qualification stream: </p>';
	            foreach ($streams as $lavel_2):
		            $html .= '<p class="anc"><a class="level_one_stream" data-parent="'.$_POST['level_one'].'" data-value="'.esc_attr($lavel_2->id).'">'.esc_html($lavel_2->name).'</a></p>';
		        endforeach;
		    }else{
                $post_data = get_post_withMeta('first', $_POST['level_one']);
                if($post_data){
                    foreach ($post_data as $key => $post) {
                        $html .= '<p><a href="'.$post->guid.'">'.$post->post_title.'</a></p>';
                    }
                }
            }
    	}else{
    		$streams = check_next_level_edu_data('sec_tab', $_POST['level_one']);
    		if($streams){
                $html .= '<input type="hidden" id="res_level_one" value="'.$_POST['level_one'].'">';
	    		$html .= '<p>Qualification level 2: </p>';
	            foreach ($streams as $lavel_2):
		            $html .= '<p class="anc"><a class="level_two_main" data-value="'.esc_attr($lavel_2->id).'">'.esc_html($lavel_2->name).'</a></p>';
		        endforeach;
		    }else{
		    	$post_data = get_post_withMeta('first', $_POST['level_one']);
		    	if($post_data){
		    		foreach ($post_data as $key => $post) {
		    			$html .= '<p><a href="'.$post->guid.'">'.$post->post_title.'</a></p>';
		    		}
		    	}
		    }
    	}
        echo $html;
    }
    die;
}

add_action('wp_ajax_wporg_ajax_change', 'wporg_meta_box_ajax_handler');
add_action('wp_ajax_nopriv_wporg_ajax_change', 'wporg_meta_box_ajax_handler');
function wporg_meta_box_wporg_ajax_tow_main_handler()
{
	$html = '';
    if (isset($_POST['level_two'])) {
    	if(check_next_level_edu_data('tab_collage_stream', $_POST['level_two'])){
    		$streams = check_next_level_edu_data('tab_collage_stream', $_POST['level_two']);
    		if($streams){
                $html .= '<input type="hidden" id="res_level_one" value="'.$_POST['level_one'].'">';
                $html .= '<input type="hidden" id="res_level_two" value="'.$_POST['level_two'].'">';
    			$html .= '<p>Qualification stream: </p>';
	            foreach ($streams as $lavel_2):
		            $html .= '<p class="anc"><a class="level_two_stream" data-value="'.esc_attr($lavel_2->id).'">'.esc_html($lavel_2->name).'</a></p>';
		        endforeach;
		    }
    	}else{
            $post_data = get_post_withMeta('second_hss', $_POST['level_one'], $_POST['level_two']);
            if($post_data){
                foreach ($post_data as $key => $post) {
                    $html .= '<p><a href="'.$post->guid.'">'.$post->post_title.'</a></p>';
                }
            }
        }
        echo $html;
    }
    // ajax handlers must die
    die;
}

add_action('wp_ajax_wporg_ajax_tow_main', 'wporg_meta_box_wporg_ajax_tow_main_handler');
add_action('wp_ajax_nopriv_wporg_ajax_tow_main', 'wporg_meta_box_wporg_ajax_tow_main_handler');


function wporg_wporg_ajax_jr_coll_course_handler(){
    $school = $_POST['level_one'];
    $lev_2 = $_POST['level_two'];
    $stream = $_POST['level_stream'];
    $post_data = get_post_withMeta('dip_iti', $school, $lev_2, $stream);
    $html = '';
    if($post_data){
        foreach ($post_data as $key => $post) {
            $html .= '<p><a href="'.$post->guid.'">'.$post->post_title.'</a></p>';
        }
    }
    echo $html;
    die;
}
add_action('wp_ajax_wporg_ajax_jr_coll_course', 'wporg_wporg_ajax_jr_coll_course_handler');
add_action('wp_ajax_nopriv_wporg_ajax_jr_coll_course', 'wporg_wporg_ajax_jr_coll_course_handler');


function wporg_ajax_cousre_in_college_handler(){
    $school = $_POST['level_one'];
    $lev_2 = $_POST['level_two'];
    $stream = $_POST['level_stream'];
    $post_data = get_post_withMeta('col_main', $school, $lev_2, $stream);
    $html = '';
    if($post_data){
        foreach ($post_data as $key => $post) {
            $html .= '<p><a href="'.$post->guid.'">'.$post->post_title.'</a></p>';
        }
    }
    echo $html;
    die;
}
add_action('wp_ajax_wporg_ajax_cousre_in_college', 'wporg_ajax_cousre_in_college_handler');
add_action('wp_ajax_nopriv_wporg_ajax_cousre_in_college', 'wporg_ajax_cousre_in_college_handler');

function wporg_meta_box_wporg_ajax_coll_course_handler()
{
	$html = '';
    if (isset($_POST['level_one']) && isset($_POST['level_stream'])) {
    	if(check_coll_course_edu_data($_POST['level_one'], $_POST['level_stream'])){
    		$streams = check_coll_course_edu_data($_POST['level_one'], $_POST['level_stream']);
    		if($streams):
                $html .= '<input type="hidden" id="res_level_one" value="'.$_POST['level_one'].'">';
                $html .= '<input type="hidden" id="res_level_one_strm" value="'.$_POST['level_stream'].'">';
    			$html .= '<p>graduation course: </p>';
	            foreach ($streams as $lavel_2):
		            $html .= '<p><a class="level_coll_course" value="'.esc_attr($lavel_2->id).'">'.esc_html($lavel_2->name).'</a></p>';
		        endforeach;
		    endif;
    	}else{
            $post_data = get_post_withMeta('only_hss_school', $_POST['level_one'], $_POST['level_stream']);
            if($post_data){
                foreach ($post_data as $key => $post) {
                    $html .= '<p><a href="'.$post->guid.'">'.$post->post_title.'</a></p>';
                }
            }
        }
        echo $html;
    }
    // ajax handlers must die
    die;
}

add_action('wp_ajax_wporg_ajax_coll_course', 'wporg_meta_box_wporg_ajax_coll_course_handler');
add_action('wp_ajax_nopriv_wporg_ajax_coll_course', 'wporg_meta_box_wporg_ajax_coll_course_handler');


/*
*
* Frontend part
*/

function wporg_frontend_scripts()
{
	wp_enqueue_script('wporg_fronend_script', get_theme_file_uri( '/assets/js/front-end.js' ), ['jquery']);
    // localize script, create a custom js object
    wp_localize_script(
        'wporg_fronend_script',
        'wporg_front_obj',
        [
            'url' => admin_url('admin-ajax.php'),
        ]
    );
}
add_action('wp_enqueue_scripts', 'wporg_frontend_scripts');

function wporg_show_search_result_ajax_coll_course_handler()
{
	$data = $_POST['data']; 
	parse_str($data, $form);
	/*if ( !wp_verify_nonce( $form['rudr_search_nonce'], 'rudr_search_nonce' ) )
		echo 'invalid'; die;*/
	
    if (isset($form['level_one_select'])) {
    	
    }
    if (isset($form['level_two_main'])) {
    	
    }
    if (isset($form['level_two_stream'])) {
    	
    }
    if (isset($form['level_one_stream'])) {
    	
    }
    if (isset($form['level_coll_course'])) {
    	
    }
    
    // ajax handlers must die
    die;
}

add_action('wp_ajax_wporg_show_search_result', 'wporg_show_search_result_ajax_coll_course_handler');
add_action('wp_ajax_nopriv_wporg_show_search_result', 'wporg_show_search_result_ajax_coll_course_handler');