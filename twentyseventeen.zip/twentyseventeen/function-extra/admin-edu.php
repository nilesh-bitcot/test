<?php
function rudr_add_a_metabox() {
	add_meta_box(
		'rudr_metabox', // metabox ID, it also will be the HTML id attribute
		'My custom metabox', // title
		'rudr_display_metabox', // this is a callback function, which will print HTML of our metabox
		'post', // post type or post types in array
		'normal', // position on the screen where metabox should be displayed (normal, side, advanced)
		'default' // priority over another metaboxes on this page (default, low, high, core)
	);
}
 
add_action( 'admin_menu', 'rudr_add_a_metabox' );

function rudr_display_metabox( $post ) {
	/*
	 * needed for security reasons
	 */
	wp_nonce_field( basename( __FILE__ ), 'rudr_metabox_nonce' );
	/*
	 * text field
	 */
	$post_id = $post->ID;
	$school = get_post_meta( $post_id, 'school', true );
	$school_stream = get_post_meta( $post_id, 'school_stream', true );
	$after_school = get_post_meta( $post_id, 'after_school', true );
	$college_crs = get_post_meta( $post_id, 'college_course', true );
	$aftr_sc_strm = get_post_meta( $post_id, 'after_school_stream', true );
	echo 's -'.$school.'<br>';
	echo 'ss -'.$school_stream.'<br>';
	echo 'as -'.$after_school.'<br>';
	echo 'cc -'.$college_crs.'<br>';
	echo 'asc -'.$aftr_sc_strm.'<br>';
	?>
	<p>
        <label for="level_one_select">Qualification 1: </label>
        <select name='level_one_select' id='level_one_select'>
        	<option value="0">select</option>
            <?php $lavel_one=get_first_lavel_edu_data(); 
            foreach ($lavel_one as $lavel_1):
            	$select = '';
            	if($lavel_1->id == $school)
            		$select = 'selected'; 
            	?>
	            <option value="<?php echo esc_attr($lavel_1->id); ?>" <?php echo $select; ?> ><?php echo esc_html($lavel_1->name); ?></option>
	            <?php 
	        endforeach; 
	        ?>
        </select>
    </p>
	<?php
	if(!empty($school_stream)){
		?>
		<p class="step_two_select">
			<label for="level_two_main">Qualification level 2: 5</label>
			<select name="level_two_main" id="level_two_main">
				<option value="0">select</option>
				<?php $lavel_two=get_allrow_table('tab_school_stream'); 
	            foreach ($lavel_two as $lavel_1):
	            	$select = '';
	            	if($lavel_1->id == $school_stream)
	            		$select = 'selected'; 
	            	?>
		            <option value="<?php echo esc_attr($lavel_1->id); ?>" <?php echo $select; ?> ><?php echo esc_html($lavel_1->name); ?></option>
		            <?php 
		        endforeach; 
		        ?>
			</select>
		</p>
		<?php
	}
	if(!empty($college_crs)){
		?>
		<p class="step_two_select">
			<label for="level_one_stream">Qualification stream: 3</label>
			<select name="level_one_stream" id="level_one_stream">
				<option value="0">select</option>
				<?php $lavel_two=get_allrow_table('college_course'); 
	            foreach ($lavel_two as $lavel_1):
	            	$select = '';
	            	if($lavel_1->id == $college_crs)
	            		$select = 'selected'; 
	            	?>
		            <option value="<?php echo esc_attr($lavel_1->id); ?>" <?php echo $select; ?> ><?php echo esc_html($lavel_1->name); ?></option>
		            <?php 
		        endforeach; 
		        ?>
			</select>
		</p>
		<?php
	}
	if(!empty($after_school)){
		?>
		<p class="step_three_select">
			<label for="level_two_stream">Qualification stream: 4 </label>
			<select name="level_two_stream" id="level_two_stream">
				<option value="0">select</option>
				<?php $lavel_two=get_allrow_table('sec_tab'); 
	            foreach ($lavel_two as $lavel_1):
	            	$select = '';
	            	if($lavel_1->id == $after_school)
	            		$select = 'selected'; 
	            	?>
		            <option value="<?php echo esc_attr($lavel_1->id); ?>" <?php echo $select; ?> ><?php echo esc_html($lavel_1->name); ?></option>
		            <?php 
		        endforeach; 
		        ?>
			</select>
		</p>
		<?php
	}
	if(!empty($aftr_sc_strm)){
		?>
		<p class="step_three_select">
			<label for="level_coll_course">Qualification stream: 56</label>
			<select name="level_coll_course" id="level_coll_course">
				<option value="0">select</option>
				<?php $lavel_two=get_allrow_table('tab_collage_stream'); 
	            foreach ($lavel_two as $lavel_1):
	            	$select = '';
	            	if($lavel_1->id == $aftr_sc_strm)
	            		$select = 'selected'; 
	            	?>
		            <option value="<?php echo esc_attr($lavel_1->id); ?>" <?php echo $select; ?> ><?php echo esc_html($lavel_1->name); ?></option>
		            <?php 
		        endforeach; 
		        ?>
			</select>
		</p>
		<?php
	}
	
}

function get_allrow_table($table='')
{
	global $wpdb;
	$fulltable = $wpdb->prefix . $table;
	$rows = $wpdb->get_results( "SELECT * FROM $fulltable");
	if($wpdb->num_rows){
		return $rows;
	}else{
		return false;
	}
}


function rudr_save_post_meta( $post_id, $post ) {
	/* 
	 * Security checks
	 */
	if ( !isset( $_POST['rudr_metabox_nonce'] ) 
	|| !wp_verify_nonce( $_POST['rudr_metabox_nonce'], basename( __FILE__ ) ) )
		return $post_id;
	/* 
	 * Check current user permissions
	 */
	$post_type = get_post_type_object( $post->post_type );
	if ( !current_user_can( $post_type->cap->edit_post, $post_id ) )
		return $post_id;
	/*
	 * Do not save the data if autosave
	 */
	if ( defined('DOING_AUTOSAVE') && DOING_AUTOSAVE ) 
		return $post_id;
 
	if ($post->post_type == 'post') { // define your own post type here
		if(isset($_POST['level_one_select']))
			update_post_meta($post_id, 'school', sanitize_text_field( $_POST['level_one_select'] ) );
		if(isset($_POST['level_one_stream']))
			update_post_meta($post_id, 'school_stream', $_POST['level_one_stream']);
		if(isset($_POST['level_two_main']))
			update_post_meta($post_id, 'after_school', $_POST['level_two_main']);
		if(isset($_POST['level_coll_course']))
			update_post_meta($post_id, 'college_course', $_POST['level_coll_course']);
		if(isset($_POST['level_two_stream']))
			update_post_meta($post_id, 'after_school_stream', $_POST['level_two_stream']);
	}
	return $post_id;
}
 


add_action( 'save_post', 'rudr_save_post_meta', 10, 2 );

function get_first_lavel_edu_data(){
	global $wpdb;
	$table = $wpdb->prefix . 'main_tab';
	$rows = $wpdb->get_results( "SELECT * FROM $table");
	if($wpdb->num_rows){
		return $rows;
	}else{
		return false;
	}
}

function check_next_level_edu_data($table, $parent_id){
	global $wpdb;
	$fulltable = $wpdb->prefix . $table;
	$rows = $wpdb->get_results( "SELECT * FROM $fulltable WHERE parent = '$parent_id'");
	if($wpdb->num_rows){
		return $rows;
	}else{
		return false;
	}
}

function check_coll_course_edu_data($parent_one, $parent_stream) {
	global $wpdb;
	$fulltable = $wpdb->prefix . 'college_course';
	$rows = $wpdb->get_results( "SELECT * FROM $fulltable WHERE level_one_parent = '$parent_one' AND level_one_stream = '$parent_stream'");
	if($wpdb->num_rows){
		return $rows;
	}else{
		return false;
	}	
}

function wporg_meta_box_scripts()
{
    // get current admin screen, or null
    $screen = get_current_screen();
    // verify admin screen object
    if (is_object($screen)) {
        // enqueue only for specific post types
        if (in_array($screen->post_type, ['post'])) {
            // enqueue script
            wp_enqueue_script('wporg_meta_box_script', get_theme_file_uri( '/assets/js/admin.js' ), ['jquery']);
            // localize script, create a custom js object
            wp_localize_script(
                'wporg_meta_box_script',
                'wporg_meta_box_obj',
                [
                    'url' => admin_url('admin-ajax.php'),
                ]
            );
        }
    }
}
add_action('admin_enqueue_scripts', 'wporg_meta_box_scripts');


function wporg_meta_box_ajax_handler_add()
{
	$html = '';
    if (isset($_POST['level_one'])) {
    	if(check_next_level_edu_data('tab_school_stream', $_POST['level_one'])){
    		$streams = check_next_level_edu_data('tab_school_stream', $_POST['level_one']);
    		if($streams):
	    		$html .= '<label for="level_one_stream">Qualification stream: </label>';
		        $html .= '<select name="level_one_stream" id="level_one_stream">';
		        	$html .= '<option value="0">select</option>';
		            foreach ($streams as $lavel_2):
			            $html .= '<option value="'.esc_attr($lavel_2->id).'">'.esc_html($lavel_2->name).'</option>';
			        endforeach;
		        $html .= '</select>';
		    endif;
    	}else{
    		$streams = check_next_level_edu_data('sec_tab', $_POST['level_one']);
    		if($streams):
	    		$html .= '<label for="level_two_main">Qualification level 2: </label>';
		        $html .= '<select name="level_two_main" id="level_two_main">';
		            $html .= '<option value="0">select</option>';
		            foreach ($streams as $lavel_2):
			            $html .= '<option value="'.esc_attr($lavel_2->id).'">'.esc_html($lavel_2->name).'</option>';
			        endforeach;
		        $html .= '</select>';
		    endif;
    	}
        echo $html;
    }
    die;
}

add_action('wp_ajax_wporg_ajax_change_admin', 'wporg_meta_box_ajax_handler_add');


function wporg_meta_box_wporg_ajax_tow_main_handler_add()
{
	$html = '';
    if (isset($_POST['level_two'])) {
    	if(check_next_level_edu_data('tab_collage_stream', $_POST['level_two'])){
    		$streams = check_next_level_edu_data('tab_collage_stream', $_POST['level_two']);
    		$html .= '<label for="level_two_stream">Qualification stream: </label>';
	        $html .= '<select name="level_two_stream" id="level_two_stream">';
	            $html .= '<option value="0">select</option>';
	            foreach ($streams as $lavel_2):
		            $html .= '<option value="'.esc_attr($lavel_2->id).'">'.esc_html($lavel_2->name).'</option>';
		        endforeach;
	        $html .= '</select>';
    	}
        echo $html;
    }
    // ajax handlers must die
    die;
}

add_action('wp_ajax_wporg_ajax_tow_main_admin', 'wporg_meta_box_wporg_ajax_tow_main_handler_add');

function wporg_meta_box_wporg_ajax_coll_course_handler_add()
{
	$html = '';
    if (isset($_POST['level_one']) && isset($_POST['level_stream'])) {
    	if(check_coll_course_edu_data($_POST['level_one'], $_POST['level_stream'])){
    		$streams = check_coll_course_edu_data($_POST['level_one'], $_POST['level_stream']);
    		$html .= '<label for="level_coll_course">graduation course: </label>';
	        $html .= '<select name="level_coll_course" id="level_coll_course">';
	            $html .= '<option value="0">select</option>';
	            foreach ($streams as $lavel_2):
		            $html .= '<option value="'.esc_attr($lavel_2->id).'">'.esc_html($lavel_2->name).'</option>';
		        endforeach;
	        $html .= '</select>';
    	}
        echo $html;
    }
    // ajax handlers must die
    die;
}

add_action('wp_ajax_wporg_ajax_coll_course_admin', 'wporg_meta_box_wporg_ajax_coll_course_handler_add');

