<?php
add_action( 'admin_menu', 'extra_post_info_menu' );
function extra_post_info_menu(){
	$page_title = 'Add Qualification For Post';
	$menu_title = 'Add Qualification';
	$capability = 'manage_options';
	$menu_slug  = 'add-qualifications';
	$function   = 'extra_post_info_page';
	$icon_url   = 'dashicons-media-code';
	$position   = 4;
	add_menu_page( $page_title, $menu_title, $capability, $menu_slug, $function, $icon_url, $position ); 
}

function extra_post_info_page(){
	global $wpdb;
	$main_tab = $wpdb->prefix.'main_tab';
	$tschool_stream = $wpdb->prefix.'tab_school_stream';
	$tasc_degree = $wpdb->prefix.'sec_tab';
	$tcol_stream = $wpdb->prefix.'tab_collage_stream';
	$tcol_course = $wpdb->prefix.'college_course';

	echo '<div class="wrap add_qualification_wrap">';
	$school_classes = get_first_lavel_edu_data(); 
	$asc_degree_data = get_allrow_table('sec_tab');
	$school_streams = get_allrow_table('tab_school_stream');
	$col_stream = get_allrow_table('tab_collage_stream');
	$col_course = get_allrow_table('college_course');
	?>
	<div id="col-left">
		<div class="col-wrap">
			<ul class="select_entries">
				<li>
					<a id="school_entry" class="entry_link" href="#">
						Enter School classes
					</a>
				</li>
				<li>
					<a id="school_stream_entry" class="entry_link" href="#">
						School classes streams/branches
					</a>
				</li>
				<li>
					<a id="degree_entry" class="entry_link" href="#">
						Enter Degree/certificate
					</a>
				</li>
				<li>
					<a id="college_course" class="entry_link" href="#">
						Enter College Courses
					</a>
				</li>
				<li>
					<a id="college_branch" class="entry_link" href="#">
						Enter College branches
					</a>
				</li>

			</ul>
			
			
		</div>
	</div>
	<div id="col-right">
		<div id="dynamic_form">
			<div id="school_entry-form" class="form_display">
				<h2>Entry Level 1</h2>	
				<div class="form-wrap">
					<h3>Add New Qualification First Level</h3>
					<form id="addqualifictations_first" method="post" action="" class="validate">
						<input type="hidden" name="action" value="add-qualification1">
						<div class="form-field form-required term-name-wrap">
							<label for="tag-name">Name/Slug</label>
							<input name="tag-name" id="name" type="text" class="slug_val" value="" size="40" aria-required="true"  data-format="special">
						</div>
						<div class="form-field term-description-wrap">
							<label for="tag-description">Description</label>
							<textarea name="description" id="description" rows="3" cols="40"></textarea>
						</div>
						<p class="submit"><input type="button" name="submit" id="submit_one" class="button button-primary" value="Add Level 1"><span class="spinner"></span></p>
					</form>
				</div>
				<div class="table_wrap">
					<?php
					$main_data = $wpdb->get_results("select * from $main_tab");
					if($main_data){
						echo '<table class="wp-list-table widefat fixed striped">';
						?>
						<tr><th>Name/slug<th><th>Description<th></tr>
						<?php
						foreach ($main_data as $key => $value) {
							echo '<tr><td>'.$value->name.'</td><td>'.$value->des.'</td></tr>';
						}
						echo '</table>';
					}
					?>
				</div>
			</div>
			<div id="school_stream_entry-form" class="form_display">
				<h2>Entry Level 2</h2>
				<div class="form-wrap">
					<h3>Add New School Stream</h3>
					<form id="addqualifictations_first_stream" method="post" action="" class="validate">
						<input type="hidden" name="action" value="add-qualification2">
						<div class="form-field form-required term-name-wrap">
							<label for="tag-name">Name/Slug</label>
							<input name="tag-name" id="sc_name" type="text" class="slug_val" value="" size="40" aria-required="true"  data-format="special">
						</div>
						<div class="form-field term-description-wrap">
							<label for="tag-description">Description</label>
							<textarea name="description" id="sc_description" rows="3" cols="40"></textarea>
						</div>
						<div class="form-field term-parent-wrap">
							<label for="parent">Parent Category</label>
							<select name="parent" id="sc_parent" class="postform">
								<option value="-1" disabled="disabled" selected>None</option>
								<?php
								if(!empty($school_classes)){
									foreach ($school_classes as $key => $value) {
										?>
							            <option value="<?php echo esc_attr($value->id); ?>">
							            	<?php echo esc_html($value->name); ?>
							            </option>
							            <?php 
									}
								}
								?>
							</select>
						</div>
						<p class="submit"><input type="button" name="submit" id="sc_submit" class="button button-primary" value="Add School Stream"><span class="spinner"></span></p>
					</form>
				</div>
				<div class="table_wrap">
					<?php
					$main_data = $wpdb->get_results("SELECT b.name, b.des, a.name AS pname, a.des AS pdes FROM $tschool_stream b, $main_tab a WHERE a.id = b.parent");
					if($main_data){
						echo '<table class="wp-list-table widefat fixed striped">';
						?>
						<tr><th>Name/slug</th><th>Parent</th><th>Description</th></tr>
						<?php
						foreach ($main_data as $key => $value) {
							echo '<tr><td>'.$value->name.'</td><td>'.$value->pdes.'</td><td>'.$value->des.'</td></tr>';
						}
						echo '</table>';
					}
					?>
				</div>
			</div>

			<div id="degree_entry-form" class="form_display">
				<h2>Entry Level 3</h2>
				<div class="form-wrap">
					<h3>Add After School options <span><a class="add_after_school" href="#">Add</a></span> </h3>
					<div class="add_after_school_form slideUp" style="display: none;">
					<form id="addqualifictations_degree_entry" method="post" action="" class="validate">
						<input type="hidden" name="action" value="add-qualification2">
						<div class="form-field form-required term-name-wrap">
							<label for="tag-name">Name/Slug</label>
							<input name="tag-name" id="sc_name" type="text" class="slug_val" value="" size="40" aria-required="true"  data-format="special">
						</div>
						<div class="form-field term-description-wrap">
							<label for="tag-description">Description</label>
							<textarea name="description" id="sc_description" rows="3" cols="40"></textarea>
						</div>
						<div class="form-field term-parent-wrap">
							<label for="parent">Parent Category</label>
							<select name="sca_parent" id="sca_parent" class="postform">
								<option value="-1" disabled="disabled" selected>None</option>
								<?php
								if(!empty($school_classes)){
									foreach ($school_classes as $key => $value) {
										?>
							            <option value="<?php echo esc_attr($value->id); ?>">
							            	<?php echo esc_html($value->name); ?>
							            </option>
							            <?php 
									}
								}
								?>
							</select>
						</div>
						<div class="form-field term-parent-wrap">
							<label for="parent">School stream</label>
							<select name="sca_parent_strm" id="sca_parent_strm" class="postform">
								<option value="-1" disabled="disabled" selected>None</option>
								<?php
								if(!empty($school_streams)){
									foreach ($school_streams as $key => $value) {
										?>
							            <option value="<?php echo esc_attr($value->id); ?>">
							            	<?php echo esc_html($value->name); ?>
							            </option>
							            <?php 
									}
								}
								?>
							</select>
						</div>
						<p class="submit"><input type="button" name="submit" id="sca_submit" class="button button-primary" value="Add School Stream"><span class="spinner"></span></p>
					</form>
				</div>
				</div>
				<div class="table_wrap">
					<?php
					$main_data = $wpdb->get_results("SELECT c.name as name, c.des as des, c.school_stream as sid,  a.name AS pname, a.des AS pdes FROM $tasc_degree c, $main_tab a WHERE a.id = c.parent");
					if($main_data){
						echo '<table class="wp-list-table widefat fixed striped">';
						?>
						<tr><th>Name/slug</th><th>Description</th><th>Parent</th><th>Parent stream</th></tr>
						<?php
						foreach ($main_data as $key => $value) {
							$pstream = '';
							$streamName = $wpdb->get_row("SELECT * FROM $tschool_stream WHERE id = '$value->sid'");
							if(isset($streamName->name)){
								$pstream = $streamName->name;
							}
							echo '<tr><td>'.$value->name.'</td><td>'.$value->des.'</td><td>'.$value->pdes.'</td><td>'.$pstream.'</td></tr>';
						}
						echo '</table>';
					}
					?>
				</div>
			</div>

			<div id="college_course-form" class="form_display">
				<h2>Entry Level 4</h2>
				<div class="form-wrap">
					<h3>Add College course <span><a class="add_col_course" href="#">Add</a></span> </h3>
					<div class="add_col_course_form slideUp" style="display: none;">
					<form id="addqualifictations_college_course" method="post" action="" class="validate">
						<input type="hidden" name="action" value="add-qualification2">
						<div class="form-field form-required term-name-wrap">
							<label for="tag-name">Name/Slug</label>
							<input name="tag-name" id="sc_name" type="text" class="slug_val" value="" size="40" aria-required="true"  data-format="special">
						</div>
						<div class="form-field term-description-wrap">
							<label for="tag-description">Description</label>
							<textarea name="description" id="sc_description" rows="3" cols="40"></textarea>
						</div>
						<div class="form-field term-parent-wrap">
							<label for="parent">Parent Category</label>
							<select name="scc_parent_one" id="scc_parent_one" class="postform">
								<option value="-1" disabled="disabled" selected>None</option>
								<?php
								if(!empty($school_classes)){
									foreach ($school_classes as $key => $value) {
										?>
							            <option value="<?php echo esc_attr($value->id); ?>">
							            	<?php echo esc_html($value->name); ?>
							            </option>
							            <?php 
									}
								}
								?>
							</select>
						</div>

						<div class="form-field term-parent-wrap">
							<label for="parent">Course in Category</label>
							<select name="scc_parent_two" id="scc_parent_two" class="postform">
								<option value="-1" disabled="disabled" selected>None</option>
								<?php
								if(!empty($asc_degree_data)){
									foreach ($asc_degree_data as $key => $value) {
										?>
							            <option value="<?php echo esc_attr($value->id); ?>">
							            	<?php echo esc_html($value->name); ?>
							            </option>
							            <?php 
									}
								}
								?>
							</select>
						</div>

						<div class="form-field term-parent-wrap">
							<label for="parent">Course branch in Category</label>
							<select name="scc_parent_three" id="scc_parent_three" class="postform">
								<option value="-1" disabled="disabled" selected>None</option>
								<?php
								if(!empty($col_stream)){
									foreach ($col_stream as $key => $value) {
										$pName = $wpdb->get_row("SELECT * FROM $main_tab WHERE id = '$value->parent'");
										?>
							            <option value="<?php echo esc_attr($value->id); ?>">
							            	<?php echo esc_html($value->name).':'.$pName->name; ?>
							            </option>
							            <?php 
									}
								}
								?>
							</select>
						</div>
						
						<p class="submit"><input type="button" name="submit" id="acc_submit" class="button button-primary" value="Add School Stream"><span class="spinner"></span></p>
					</form>
				</div>
				</div>
				<div class="table_wrap">
					<?php
					$main_data = $wpdb->get_results("SELECT c.name as name, c.des as des, c.level_one_parent as l_one_pid, c.level_one_stream as l_one_sid,  a.name AS pname, a.des AS pdes FROM $tcol_course c, $main_tab a WHERE a.id = c.parent");
					if($main_data){
						echo '<table class="wp-list-table widefat fixed striped">';
						?>
						<tr><th>Name/slug</th><th>Description</th><th>Parent</th><th>Parent sec</th><th>college stream</th></tr>
						<?php
						foreach ($main_data as $key => $value) {
							$pstream = '';
							$psec_name = '';
							$streamName = $wpdb->get_row("SELECT * FROM $tcol_stream WHERE id = '$value->l_one_sid'");
							$secPName = $wpdb->get_row("SELECT * FROM $tasc_degree WHERE id = '$value->l_one_pid'");
							if(isset($streamName->name)){
								$pstream = $streamName->name;
							}
							if(isset($secPName->name)){
								$psec_name = $secPName->name;
							}
							echo '<tr><td>'.$value->name.'</td><td>'.$value->des.'</td><td>'.$value->pdes.'</td><td>'.$psec_name.'</td><td>'.$pstream.'</td></tr>';
						}
						echo '</table>';
					}
					?>
				</div>
			</div>

			<div id="college_branch-form" class="form_display">
				<h2>Entry Level 4</h2>
				<div class="form-wrap">
					<h3>Add College Branches <span><a class="add_col_branch" href="#">Add</a></span> </h3>
					<div class="add_col_branch_form slideUp" style="display: none;">
					<form id="addqualifictations_college_course" method="post" action="" class="validate">
						<input type="hidden" name="action" value="add-qualification2">
						<div class="form-field form-required term-name-wrap">
							<label for="tag-name">Name/Slug</label>
							<input name="tag-name" id="sc_name" type="text" class="slug_val" value="" size="40" aria-required="true"  data-format="special">
						</div>
						<div class="form-field term-description-wrap">
							<label for="tag-description">Description</label>
							<textarea name="description" id="sc_description" rows="3" cols="40"></textarea>
						</div>
						<div class="form-field term-parent-wrap">
							<label for="parent">Parent Category</label>
							<select name="sca_parent" id="sca_parent" class="postform">
								<option value="-1" disabled="disabled" selected>None</option>
								<?php
								if(!empty($school_classes)){
									foreach ($school_classes as $key => $value) {
										?>
							            <option value="<?php echo esc_attr($value->id); ?>">
							            	<?php echo esc_html($value->name); ?>
							            </option>
							            <?php 
									}
								}
								?>
							</select>
						</div>
						<p class="submit"><input type="button" name="submit" id="acs_submit" class="button button-primary" value="Add School Stream"><span class="spinner"></span></p>
					</form>
				</div>
				</div>
				<div class="table_wrap">
					<?php
					$main_data = $wpdb->get_results("SELECT c.name as name, c.des as des, a.name AS pname, a.des AS pdes FROM $tcol_stream c, $main_tab a WHERE a.id = c.parent");
					if($main_data){
						echo '<table class="wp-list-table widefat fixed striped">';
						?>
						<tr><th>Name/slug</th><th>Description</th><th>Parent</th></tr>
						<?php
						foreach ($main_data as $key => $value) {
							$pstream = '';
							$streamName = $wpdb->get_row("SELECT * FROM $tschool_stream WHERE id = '$value->sid'");
							if(isset($streamName->name)){
								$pstream = $streamName->name;
							}
							echo '<tr><td>'.$value->name.'</td><td>'.$value->des.'</td><td>'.$value->pdes.'</td></tr>';
						}
						echo '</table>';
					}
					?>
				</div>
			</div>
			
		</div>
	</div>

	<?php
	echo '</div>';
}

add_action( 'admin_footer', 'add_script_for_add_qualifications' );
function add_script_for_add_qualifications(){
	global $pagenow;
	if(isset($_GET['page']) && $_GET['page'] == 'add-qualifications'){
		?>

	<script type="text/javascript">
		var dynamic_form = jQuery('.form_display');
		jQuery(document).ready(function($){
			dynamic_form.hide();
			jQuery('#school_entry-form').show();
			$('.entry_link').click(function(event){
				event.preventDefault();
				$('.slideUp').slideUp();
				var that = this;
				var $that = $(this);
				var id = that.id;
				dynamic_form.hide();
				jQuery('#'+id+'-form').show();

			});
			$('.add_after_school').click(function(e){
				e.preventDefault();
				$('.add_after_school_form').slideToggle();
			});
			$('.add_col_course').click(function(e){
				e.preventDefault();
				$('.add_col_course_form').slideToggle();
			});
			$('.add_col_branch').click(function(e){
				e.preventDefault();
				$('.add_col_branch_form').slideToggle();
			});
			
			$('#submit_one').click(function(){
				var forms = jQuery(this).closest("form");
				var name = forms.find("[name=tag-name]").val();
				var description = forms.find("[name=description]").val();
				if(name == '' || description == ''){
					alert("please fill data");
					return false;
				}
				var data ={
					action:'save_school_class',
					name:name,
					description:description
				};
				$.post(ajaxurl, data, function(response){
					console.log(response);
					if(response == 'exist'){
						alert('already exist with same name field');
					}else if(response == 'fail'){
						alert('some error occur try later');
					}else{
						window.location.reload();
					}
				});
			});

			$('#sc_submit').click(function(){
				var forms = jQuery(this).closest("form");
				var name = forms.find("[name=tag-name]").val();
				var description = forms.find("[name=description]").val();
				var parent = forms.find("[name=parent]").val();
				if(name == '' || description == ''){
					alert("please fill data");
					return false;
				}
				if(parent == null || parent == undefined){
					alert("please select parent field");
					return false;
				}
				
				var data ={
					action:'save_school_stream',
					name:name,
					description:description,
					parent:parent
				};
				$.post(ajaxurl, data, function(response){
					console.log(response);
					if(response == 'exist'){
						alert('already exist with same name field');
					}else if(response == 'fail'){
						alert('some error occur try later');
					}else{
						window.location.reload();
					}
				});
			});


			$('#sca_submit').click(function(){
				var forms = jQuery(this).closest("form");
				var name = forms.find("[name=tag-name]").val();
				var description = forms.find("[name=description]").val();
				var parent = forms.find("[name=sca_parent]").val();
				var sca_parent_strm = forms.find("[name=sca_parent_strm]").val();
				if(name == '' || description == ''){
					alert("please fill data");
					return false;
				}
				if(parent == null || parent == undefined){
					alert("please select parent field");
					return false;
				}
				
				var data ={
					action:'save_after_school',
					name:name,
					description:description,
					parent:parent,
					sca_parent_strm:sca_parent_strm
				};

				$.post(ajaxurl, data, function(response){
					console.log(response);
					if(response == 'exist'){
						alert('already exist with same name field');
					}else if(response == 'fail'){
						alert('some error occur try later');
					}else{
						window.location.reload();
					}
				});
			});
			
			$('#acs_submit').click(function(){
				var forms = jQuery(this).closest("form");
				var name = forms.find("[name=tag-name]").val();
				var description = forms.find("[name=description]").val();
				var parent = forms.find("[name=sca_parent]").val();
				if(name == '' || description == ''){
					alert("please fill data");
					return false;
				}
				if(parent == null || parent == undefined){
					alert("please select parent field");
					return false;
				}
				
				var data ={
					action:'save_college_stream',
					name:name,
					description:description,
					parent:parent
				};
				
				$.post(ajaxurl, data, function(response){
					console.log(response);
					if(response == 'exist'){
						alert('already exist with same name field');
					}else if(response == 'fail'){
						alert('some error occur try later');
					}else{
						window.location.reload();
					}
				});
			});

			$('#acc_submit').click(function(){
				var forms = jQuery(this).closest("form");
				var name = forms.find("[name=tag-name]").val();
				var description = forms.find("[name=description]").val();
				var parent = forms.find("[name=scc_parent_one]").val();
				var scc_parent_two = forms.find("[name=scc_parent_two]").val();
				var scc_parent_three = forms.find("[name=scc_parent_three]").val();
				if(name == '' || description == ''){
					alert("please fill data");
					return false;
				}
				if(parent == null || parent == undefined){
					alert("please select parent field");
					return false;
				}
				if(scc_parent_two == null || scc_parent_two == undefined){
					alert("Please select course in Category");
					return false;
				}
				
				var data ={
					action:'save_college_course',
					name:name,
					description:description,
					parent:parent,
					scc_parent_two:scc_parent_two,
					scc_parent_three:scc_parent_three
				};
				
				$.post(ajaxurl, data, function(response){
					console.log(response);
					if(response == 'exist'){
						alert('already exist with same name field');
					}else if(response == 'fail'){
						alert('some error occur try later');
					}else{
						window.location.reload();
					}
				});
			});
		});
	</script>
	<script type="text/javascript">


jQuery('body').on('keyup keypress', function(e) {
  var keyCode = e.keyCode || e.which;
  if (keyCode === 13) { 
    e.preventDefault();
    return false;
  }
});

const elementSelector = {
  password:'.passwordInput',
  username:'.slug_val',
  phone:'.phoneInput',
  phoneFormat:'({0}{1}{2}) {3}{4}{5}-{6}{7}{8}{9}',
  dataFormatAttr:'data-format',
  dataAlphaNum: 'alphanum',
  dataSpecial:'special',
  dataStrengthAttr:'data-strength',
  dataStrongStrength:'strong'
};


const passwordInputs = document.querySelectorAll(elementSelector.password);

passwordInputs.forEach((pswdInput) => {
  pswdInput.addEventListener('input', (event) => {
    if(pswdInput.value.length < 4){
      pswdInput.style.color = "red";
      return;
    }

    var regex = new Array();
    regex.push("[A-Z]");
    regex.push("[a-z]");
    regex.push("[0-9]");

    if(pswdInput.hasAttribute(elementSelector.dataStrengthAttr)){
      if(pswdInput.getAttribute(elementSelector.dataStrengthAttr) == elementSelector.dataStrongStrength){
        regex.push("[$@$!%*#?&]");
      }
    }

    var passed = 0;
    for (var i = 0; i < regex.length; i++) {
      if (new RegExp(regex[i]).test(pswdInput.value)) {
          passed++;
      }
    }
console.log(passed);
    //Validate for length of Password.
    if (passed > 2 && pswdInput.value.length > 8) {
      passed++;
    }
    
    let color = "";
    let strength = "";
    switch (passed) {
      case 0:
      case 1:
        strength = "Weak";
        color = "red";
        break;
      case 2:
        strength = "Good";
        color = "darkorange";
        break;
      case 3:
      case 4:
        strength = "Strong";
        color = "green";
        break;
      case 5:
        strength = "Very Strong";
        color = "darkgreen";
        break;
    }
    pswdInput.style.color = color;
    if(event.inputType !== undefined){
      if (event.inputType.includes('deleteContent')) {
        return;
      }  
    }
  });

  pswdInput.addEventListener('focusout', (event) => {
    pswdInput.removeAttribute('style');
  });
  pswdInput.addEventListener('focusin', (event) => {
    var event = document.createEvent('Event');
    event.initEvent('input', true, true);
    pswdInput.dispatchEvent(event);
  });
});


const usernameInputs = document.querySelectorAll(elementSelector.username);

usernameInputs.forEach((userInput) => {
  userInput.addEventListener('input', (event) => {
    let regex = /[^a-zA-Z ]/g;
    if(userInput.hasAttribute(elementSelector.dataFormatAttr)){
      if(userInput.getAttribute(elementSelector.dataFormatAttr) == elementSelector.dataAlphaNum){
        regex = /[^a-zA-Z0-9]/g
      }else if(userInput.getAttribute(elementSelector.dataFormatAttr) == elementSelector.dataSpecial){
        regex = /[^a-zA-Z0-9-]/g
      }
    }
    const inputStripped = userInput.value.replace(regex, '-').replace(/ /g, '').toLowerCase();
    if (event.inputType.includes('deleteContent')) {
      return;
    }
    if (event.inputType == 'insertText' && (inputStripped.length > 30 )) {
      userInput.value = userInput.value.substring(0, userInput.value.length - 1);
      return;
    }
    userInput.value = inputStripped;
  });
});

const phoneInputs = document.querySelectorAll(elementSelector.phone);
const phoneFormat = elementSelector.phoneFormat;

phoneInputs.forEach((phoneInput) => {
  phoneInput.addEventListener('input', (event) => {
    const inputStripped = phoneInput.value.replace(/\D/g, '');
    const inputIsValid = !isNaN(parseInt(event.data));

    if (event.inputType.includes('deleteContent')) {
      return;
    }
    if (event.inputType == 'insertText' && (inputStripped.length > 10 || !inputIsValid)) {
      phoneInput.value = phoneInput.value.substring(0, phoneInput.value.length - 1);
      return;
    }

    if (inputStripped){
      phoneInput.value = formatPhoneInput(inputStripped);
    }
  });
});

const formatPhoneInput = (inputNumber) => {
  let inputNumArr = inputNumber.split('');
  let formatVar = inputNumArr.length - 1;
  
  // indexOf() + 3, so we can replace the entire '{x}' variable in phoneFormat
  let replaceIndex = phoneFormat.indexOf(`{${formatVar}}`) + 3;
  
  // Autocompletion to next input value
  switch (formatVar) {
    case 2:
      replaceIndex += 2;
      break;
    case 5:
      replaceIndex += 1;
      break;
    default:
      break;
  }
  
  // phoneFormat substring based on the current number length
  let formattedInput = phoneFormat.substring(0, replaceIndex);

  for (let i = 0; i < inputNumArr.length; i++) {
    formattedInput = formattedInput.replace(`{${i}}`, inputNumArr[i]);
  }

  return formattedInput;
}

	</script>
	<?php
	}
}

add_action( 'admin_head', 'add_style_for_add_qualifications' );
function add_style_for_add_qualifications(){
	global $pagenow;
	?>
	<style type="text/css">
		ul.select_entries li {
		    padding: 5px 10px;
		    background: #b3e0ef;
		}

		ul.select_entries li a {
			text-decoration: none;
			font-weight: bold;
		}
		#dynamic_form {
			background: #fbfbe6;
			padding: 5px 10px;
		}
		#dynamic_form h2 {
			background: #81dbf0;
			padding: 2px;
		}
		#dynamic_form table.wp-list-table tr th {
			border-bottom: 1px solid !important;	
		}
	</style>
	<?php
}


add_action('wp_ajax_save_school_class', 'wporg_add_save_school_class');
function wporg_add_save_school_class()
{
	global $wpdb;
	echo json_encode($_POST);die;
	$name = $_POST['name'];
	$description = $_POST['description'];
	$table = $wpdb->prefix.'main_tab';
	$check = $wpdb->query("SELECT * FROM $table WHERE name='$name'");
	$result = '';
	echo json_encode($check); die;
	$data = array('name'=>$name, 'des'=>$description);
	if($check){
		$result = 'exist';
	}else{
		$wpdb->insert($table, $data);
		if($wpdb->insert_id){
			$result = 'sucess';
		}else{
			$result = 'fail';
		}
	}
	echo $result;
    die();
}

add_action('wp_ajax_save_school_stream', 'wporg_add_save_school_stream');
function wporg_add_save_school_stream()
{
	global $wpdb;
	// echo json_encode($_POST);die;
	$name = $_POST['name'];
	$description = $_POST['description'];
	$parent = $_POST['parent'];
	$table = $wpdb->prefix.'tab_school_stream';
	$check = $wpdb->query("SELECT * FROM $table WHERE name='$name' AND parent='$parent'");
	$result = '';
	$data = array('name'=>$name, 'des'=>$description, 'parent'=>$parent);
	if($check){
		$result = 'exist';
	}else{
		$wpdb->insert($table, $data);
		if($wpdb->insert_id){
			$result = 'sucess';
		}else{
			$result = 'fail';
		}
	}
	echo $result;
    die();
}
add_action('wp_ajax_save_after_school', 'wporg_add_save_after_school_options');
function wporg_add_save_after_school_options()
{
	global $wpdb;
	// echo json_encode($_POST);die;
	$name = $_POST['name'];
	$description = $_POST['description'];
	$parent = $_POST['parent'];
	$parent_s = $_POST['sca_parent_strm'];
	$table = $wpdb->prefix.'sec_tab';
	$check = $wpdb->query("SELECT * FROM $table WHERE name='$name' AND parent='$parent'");
	$result = '';

	$data = array('name'=>$name, 'des'=>$description, 'parent'=>$parent);
	if(!empty($parent_s)){
		$data['school_stream'] = $parent_s;
	}

	if($check){
		$result = 'exist';
	}else{
		$wpdb->insert($table, $data);
		if($wpdb->insert_id){
			$result = 'sucess';
		}else{
			$result = 'fail';
		}
	}
	echo $result;
    die();
}
add_action('wp_ajax_save_college_stream', 'wporg_add_save_college_stream');
function wporg_add_save_college_stream()
{
	global $wpdb;
	// echo json_encode($_POST);die;
	$name = $_POST['name'];
	$description = $_POST['description'];
	$parent = $_POST['parent'];
	$table = $wpdb->prefix.'tab_collage_stream';
	$check = $wpdb->query("SELECT * FROM $table WHERE name='$name' AND parent='$parent'");
	$result = '';

	$data = array('name'=>$name, 'des'=>$description, 'parent'=>$parent);
	
	if($check){
		$result = 'exist';
	}else{
		$wpdb->insert($table, $data);
		if($wpdb->insert_id){
			$result = 'sucess';
		}else{
			$result = 'fail';
		}
	}
	echo $result;
    die();
}
add_action('wp_ajax_save_college_course', 'wporg_add_save_college_course');
function wporg_add_save_college_course()
{
	global $wpdb;
	// echo json_encode($_POST);die;
	$name = $_POST['name'];
	$description = $_POST['description'];
	$parent = $_POST['parent'];
	$parent_two = $_POST['scc_parent_two'];
	$parent_three = $_POST['scc_parent_three'];
	$table = $wpdb->prefix.'college_course';
	$check = $wpdb->query("SELECT * FROM $table WHERE name='$name' AND parent='$parent' AND level_one_parent='$parent_two' ");
	$result = '';

	$data = array('name'=>$name, 'des'=>$description, 'parent'=>$parent);
	if(!empty($parent_two)){
		$data['level_one_parent'] = $parent_two;
	}
	if(!empty($parent_three)){
		$data['level_one_stream'] = $parent_three;
	}
	if($check){
		$result = 'exist';
	}else{
		$wpdb->insert($table, $data);
		if($wpdb->insert_id){
			$result = 'sucess';
		}else{
			$result = 'fail';
		}
	}
	echo $result;
    die();
}