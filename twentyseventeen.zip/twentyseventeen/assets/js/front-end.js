console.log("hello fornt");
/*jslint browser: true, plusplus: true */
(function ($, window, document) {
    'use strict';
    // execute when the DOM is ready
    $(document).ready(function () {
        // js 'change' event triggered on the wporg_field form field
        $('#level_one_select').on('change', function () {
            $('.step_two_select').remove();
            $('.step_three_select').remove();
            if($('#level_one_select').val() == '0')
                return false;
            // jQuery post method, a shorthand for $.ajax with POST
            $.post(wporg_front_obj.url,                        // or ajaxurl
                   {
                       action: 'wporg_ajax_change',               // POST data, action
                       level_one: $('#level_one_select').val() // POST data, wporg_field_value
                   }, function (data) {
                        // handle response data
                        if (data) {
                            // perform our success logic
                            $('#level_one_select').parent().after('<p class="step_two_select">'+data+'</p>');
                        } else {
                            // do nothing
                        }
                    }
            );
        });

        $('body').on('change', '#level_two_main', function () {
        /*$('#level_two_main').on('change', function () {*/
            $('.step_three_select').remove();
            if($('#level_two_main').val() == '0')
                return false;
            // jQuery post method, a shorthand for $.ajax with POST
            $.post(wporg_front_obj.url,                        // or ajaxurl
                   {
                       action: 'wporg_ajax_tow_main',               // POST data, action
                       level_two: $('#level_two_main').val() // POST data, wporg_field_value
                   }, function (data) {
                        // handle response data
                        if (data) {
                            // perform our success logic
                            $('#level_two_main').parent().after('<p class="step_three_select">'+data+'</p>');
                        } else {
                            // do nothing
                        }
                    }
            );
        });
        
        $('body').on('change', '#level_one_stream', function () {
        /*$('#level_two_main').on('change', function () {*/
            let this_val = $(this).val();
            $('.step_three_select').remove();
            // jQuery post method, a shorthand for $.ajax with POST
            $.post(wporg_front_obj.url,                        // or ajaxurl
                   {
                       action: 'wporg_ajax_coll_course',               // POST data, action
                       level_one: $('#level_one_select').val(), // POST data, wporg_field_value
                       level_stream: this_val
                   }, function (data) {
                        // handle response data
                        if (data) {
                            // perform our success logic
                            $('#level_one_stream').parent().after('<p class="step_three_select">'+data+'</p>');
                        } else {
                            // do nothing
                        }
                    }
            );
        });

        $('#first_form').on('submit', function(event){
        	event.preventDefault();
        	let formData = $(this).serialize();
        	
        	$.post(wporg_front_obj.url,                        // or ajaxurl
                   {
                       action: 'wporg_show_search_result',               // POST data, action
                       data: formData
                   }, function (data) {
                   	console.log(data);
                        // handle response data
                        if (data) {
                            // perform our success logic
                            $('#level_one_stream').parent().after('<p class="step_three_select">'+data+'</p>');
                        } else {
                            // do nothing
                        }
                    }
            );
        	return false;
        })
    });
}(jQuery, window, document));

/*
* New update in UI
*/

(function ($, window, document) {
    'use strict';
    // execute when the DOM is ready
    $(document).ready(function () {
        // js 'change' event triggered on the wporg_field form field
        $('.level_one_select').on('click', function (event) {
          event.preventDefault();
            $('.header-details').fadeOut('fast');
            var val = $(this).attr('data-value');
            console.log(val);
            
            if(val == '0')
                return false;
            // jQuery post method, a shorthand for $.ajax with POST
            $.post(wporg_front_obj.url,                        // or ajaxurl
                   {
                       action: 'wporg_ajax_change',               // POST data, action
                       level_one: val // POST data, wporg_field_value
                   }, function (data) {
                        // handle response data
                        if (data) { console.log(data);
                          $('#level_results').html(data);
                          $('.header-details').fadeIn('slow');
                            // perform our success logic
                            // $('#level_one_select').parent().after('<p class="step_two_select">'+data+'</p>');
                        } else {
                            // do nothing
                            $('#level_results').html('<p>no data</p>');
                            $('.header-details').fadeIn('slow');
                        }
                    }
            );
        });

        $('body').on('click', '.level_two_main', function () {
            event.preventDefault();
            $('.header-details').fadeOut('slow');
            var val = $(this).attr('data-value');
            if(val == '0')
                return false;
            console.log(val);
            var lone = $('#res_level_one').val();
            // jQuery post method, a shorthand for $.ajax with POST
            $.post(wporg_front_obj.url,                        // or ajaxurl
                   {
                       action: 'wporg_ajax_tow_main', 
                       level_one: lone,              // POST data, action
                       level_two: val // POST data, wporg_field_value
                   }, function (data) {
                        // handle response data
                        if (data) {
                            // perform our success logic
                            $('#level_results').html(data);
                            $('.header-details').fadeIn('slow');
                            // $('.level_two_main').parent().after('<p class="step_three_select">'+data+'</p>');
                        } else {
                            // do nothing
                            $('#level_results').html('<p>no data</p>');
                            $('.header-details').fadeIn('slow');
                        }
                    }
            );
        });
        
        $('body').on('click', '.level_one_stream', function () {
        /*$('#level_two_main').on('change', function () {*/
            event.preventDefault();
            $('.header-details').fadeOut('slow');
            let stream_val = $(this).attr('data-value');
            let par_val = $(this).attr('data-parent');
             if(stream_val == '0')
                return false;
            console.log(stream_val);
            // jQuery post method, a shorthand for $.ajax with POST
            $.post(wporg_front_obj.url,                        // or ajaxurl
                   {
                       action: 'wporg_ajax_coll_course',               // POST data, action
                       level_one: par_val, // POST data, wporg_field_value
                       level_stream: stream_val
                   }, function (data) {
                        // handle response data
                        if (data) {
                            // perform our success logic
                            $('#level_results').html(data);
                            $('.header-details').fadeIn('slow');
                            // $('#level_one_stream').parent().after('<p class="step_three_select">'+data+'</p>');
                        } else {
                            // do nothing
                            $('#level_results').html('<p>no data</p>');
                            $('.header-details').fadeIn('slow');
                        }
                    }
            );
        });

        $('body').on('click', '.level_two_stream', function () {
        /*$('#level_two_main').on('change', function () {*/
            event.preventDefault();
            $('.header-details').fadeOut('slow');
            let stream_val = $(this).attr('data-value');
            let par_val = $(this).attr('data-parent');
            par_val = $('#res_level_one').val();
            let lev_two_main = $('#res_level_two').val();
             if(stream_val == '0')
                return false;
            console.log(stream_val);
            // jQuery post method, a shorthand for $.ajax with POST
            $.post(wporg_front_obj.url,                        // or ajaxurl
                   {
                       action: 'wporg_ajax_jr_coll_course',               // POST data, action
                       level_one: par_val, // POST data, wporg_field_value
                       level_two: lev_two_main,
                       level_stream: stream_val
                   }, function (data) {
                        // handle response data
                        if (data) {
                            // perform our success logic
                            $('#level_results').html(data);
                            $('.header-details').fadeIn('slow');
                            // $('#level_one_stream').parent().after('<p class="step_three_select">'+data+'</p>');
                        } else {
                            // do nothing
                            $('#level_results').html('<p>no data</p>');
                            $('.header-details').fadeIn('slow');
                        }
                    }
            );
        });

        $('body').on('click', '.level_coll_course', function () {
        /*$('#level_two_main').on('change', function () {*/
            event.preventDefault();
            $('.header-details').fadeOut('slow');
            let stream_val = $(this).attr('data-value');
            let par_val = $('#res_level_one').val();
            let lev_two_main = $('#res_level_one_strm').val();
             if(stream_val == '0')
                return false;
            console.log(stream_val);
            // jQuery post method, a shorthand for $.ajax with POST
            $.post(wporg_front_obj.url,                        // or ajaxurl
                   {
                       action: 'wporg_ajax_cousre_in_college',               // POST data, action
                       level_one: par_val, // POST data, wporg_field_value
                       level_two: lev_two_main,
                       level_stream: stream_val
                   }, function (data) {
                        // handle response data
                        if (data) {
                            // perform our success logic
                            $('#level_results').html(data);
                            $('.header-details').fadeIn('slow');
                            // $('#level_one_stream').parent().after('<p class="step_three_select">'+data+'</p>');
                        } else {
                            // do nothing
                            $('#level_results').html('<p>no data</p>');
                            $('.header-details').fadeIn('slow');
                        }
                    }
            );
        });

        $('#first_form').on('submit', function(event){
          event.preventDefault();
          let formData = $(this).serialize();
          
          $.post(wporg_front_obj.url,                        // or ajaxurl
                   {
                       action: 'wporg_show_search_result',               // POST data, action
                       data: formData
                   }, function (data) {
                    console.log(data);
                        // handle response data
                        if (data) {
                            // perform our success logic
                            $('#level_one_stream').parent().after('<p class="step_three_select">'+data+'</p>');
                        } else {
                            // do nothing
                        }
                    }
            );
          return false;
        })
    });
}(jQuery, window, document));