/*jslint browser: true, plusplus: true */
(function ($, window, document) {
    'use strict';
    // execute when the DOM is ready
    $(document).ready(function () {
        // js 'change' event triggered on the wporg_field form field
        $('#level_one_select').on('change', function () {
            $('.step_two_select').remove();
            $('.step_three_select').remove();
            if($('#level_one_select').val() == '0')
                return false;
            // jQuery post method, a shorthand for $.ajax with POST
            $.post(wporg_meta_box_obj.url,                        // or ajaxurl
                   {
                       action: 'wporg_ajax_change_admin',               // POST data, action
                       level_one: $('#level_one_select').val() // POST data, wporg_field_value
                   }, function (data) {
                        console.log(data);
                        // handle response data
                        if (data) {
                            // perform our success logic
                            $('#level_one_select').parent().after('<p class="step_two_select">'+data+'</p>');
                        } else {
                            // do nothing
                        }
                    }
            );
        });

        $('body').on('change', '#level_two_main', function () {
        /*$('#level_two_main').on('change', function () {*/
            console.log("level_two");
            $('.step_three_select').remove();
            if($('#level_two_main').val() == '0')
                return false;
            // jQuery post method, a shorthand for $.ajax with POST
            $.post(wporg_meta_box_obj.url,                        // or ajaxurl
                   {
                       action: 'wporg_ajax_tow_main_admin',               // POST data, action
                       level_two: $('#level_two_main').val() // POST data, wporg_field_value
                   }, function (data) {
                        console.log(data);
                        // handle response data
                        if (data) {
                            // perform our success logic
                            $('#level_two_main').parent().after('<p class="step_three_select">'+data+'</p>');
                        } else {
                            // do nothing
                        }
                    }
            );
        });
        
        $('body').on('change', '#level_one_stream', function () {
        /*$('#level_two_main').on('change', function () {*/
            console.log("level_two");
            let this_val = $(this).val();
            $('.step_three_select').remove();
            // jQuery post method, a shorthand for $.ajax with POST
            $.post(wporg_meta_box_obj.url,                        // or ajaxurl
                   {
                       action: 'wporg_ajax_coll_course_admin',               // POST data, action
                       level_one: $('#level_one_select').val(), // POST data, wporg_field_value
                       level_stream: this_val
                   }, function (data) {
                        console.log(data);
                        // handle response data
                        if (data) {
                            // perform our success logic
                            $('#level_one_stream').parent().after('<p class="step_three_select">'+data+'</p>');
                        } else {
                            // do nothing
                        }
                    }
            );
        });
    });
}(jQuery, window, document));