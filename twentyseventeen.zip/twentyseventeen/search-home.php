<?php
/**
 * Template Name: Post search
 *
 * @package WordPress
 * @subpackage Twenty_Fifteen
 * @since Twenty Fifteen 1.0
 */

get_header(); 
?>
<style type="text/css">
	
body{

	
	background: #74b9ff;
	margin-top: 35px;
	font-size: 18px;
	font-family: arial;
	color: white;
	
}


.container{

	width: 950px;
	height: 0 auto;	
	margin: 0 auto;
}

h1{

	font-size: 45px;
}


a{

text-decoration: none;
color: white;

}

.header{

 margin: 0 auto;
	width: 100%;
	height: 300px;
	border: 0px solid red;
	text-align: center;

}
 .header-headline h1{
 	text-align: center;
  font-size: 30px;
 }

.header-menu ul{
text-decoration: none;
	float: left;
	margin: 0px auto;
	background: none;
	width: 100%;
}
.e-name h1 {
    margin: 0;
}


.header-menu li {
    float: left;
    width: 150px;
    background: 
#6a89cc;
padding: 20px;
list-style: none;
border: 0px solid
    green;
    margin-left: 20px;
    text-align: center;
    border-radius: 10px;
}

.header-details-short {
    width: 100%;
    height: auto;
    border: 0px solid green;
	background: #fff;
	margin-top: 49px;
	float: left;
	padding: 20px;
	line-height: 50px;
	border-radius: 3px;
	color: black;
	box-shadow: 8px 5px 9px -1px #595656;
}
.header-details-short a{
	color: #000000;
}
.header-details-short .anc{
	color: #000000;
	padding: 0;
}
.em-box{

 width:100%;
 height: 100px;
background:none;
float: left;
margin-top: 10px;
padding: 0px;

}

.footer-content{

 background: #2d3436;
 width: 100%;
 height: auto;
 float: left;
}



.left-footer {
    width: 45%;
    height: auto;
    border: 0px solid white;
    float: left;
}



.right-footer {

    width: auto;
    float: right;
    height: auto;
    border: 0px solid red;
    padding: 25px;
    text-align: center;

}

.f-logo {
    width: 99px;
    height: 50px;
}
.f-logo img {
    width: 50px;
}

.f-name {
    font-size: 12px;
}

.f-name h1 {
    font-size: 19px;
    color: 
    white;
}



.left-footer ul{
float: left;
text-decoration: none;
list-style: none;
color: white;
font-size: 15px;
margin-left: 15px;
line-height: 35px;
}

.remark-ed {
    text-align: center;
    color: 
white;
float: left;
width: 100%;
background:
    #2d3436;
    font-size: 12px;
}

</style>

<div class="container">
	<div class="header">
		<div class="e-logo"><a href="#"><img src="<?php echo get_template_directory_uri(); ?>/assets/images/tree.png"></a></div>
		<div class="e-name"><h1><a href="#">Edu-Tree</a></h1></div>
	</div>
	
	<div class="header-headline">
		<h1>Choose Your Stream ?</h1>
	</div>
	<div id="main_results" class="header-menu">
		<?php 
		$lavel_one=get_first_lavel_edu_data(); 
		if($lavel_one):
			echo '<ul>';
	        foreach ($lavel_one as $lavel_1): 
	        	echo '<li><a class="level_one_select" href="javascript:void(0);" data-value="'.esc_attr($lavel_1->id).'">'.esc_html($lavel_1->name).'</a></li>';
	        endforeach;
	        echo '</ul>'; 
	    endif;
        ?>
	</div>
	<div id="second_results" class="header-details">
		<div id="level_results" class="header-details-short">
			- animtion course <br>
			- animtion course <br>
			- animtion course <br>
		</div>
	</div>
	<div class="em-box"></div>
</div>
<div class="footer">
	<div class="footer-content">
		<div class="left-footer">
			<ul>
				<li><a href="#">Home</a></li>
				<li><a href="#">About</a></li>
				<li><a href="#">Contact Us</a></li>
			</ul>
			<ul>
				<li><a href="#">8th Fail/Pass</a></li>
				<li>-</li>
				<li>-</li>
			</ul>
			<ul>
				<li><a href="#">10th</a></li>
				<li>-</li>
				<li>-</li>
			</ul>
			<ul>
				<li><a href="#">12th</a></li>
				<li>-</li>
				<li>-</li>
			</ul>
			<ul>
				<li><a href="#">Other Subject</a></li>
				<li>-</li>
				<li>-</li>
			</ul>
		</div>
		<div class="right-footer">
			<div class="f-logo"><a href="#"><img src="<?php echo get_template_directory_uri(); ?>/assets/images/tree.png"></a></div>
			<div class="f-name"><a href="#"><h1>Edu-Tree</h1></a></div>
		</div>
	</div>
	<div class="remark-ed">All Content Copyright Reserved @ Edu Tree</div>
</div>

<?php get_footer(); ?>
